from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='object_detection_node',
            executable='object_detector',
            name='yolo_object_detector',
            output='screen',
            parameters=[
                {
                    'yolo_config': '/tmp/yolov3.cfg',
                    'yolo_weights': '/tmp/yolov3.weights',
                    'coco_names': '/tmp/coco.names',
                    'confidence_threshold': 0.5,
                    'nms_threshold': 0.4
                }
            ]
        )
    ])
