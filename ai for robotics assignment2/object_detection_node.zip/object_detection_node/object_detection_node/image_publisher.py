#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
import os
from ament_index_python.packages import get_package_share_directory

class SimulatedImagePublisher(Node):
    def __init__(self):
        super().__init__('simulated_image_publisher')
        
        # 创建图像发布者
        self.publisher_ = self.create_publisher(Image, '/camera/image_raw', 10)
        
        # 定时器，用于定期发布图像
        self.timer = self.create_timer(0.1, self.timer_callback)  # 10Hz
        
        # CV桥，用于转换OpenCV图像到ROS消息
        self.bridge = CvBridge()
        
        # 模拟场景创建
        self.create_simulated_scene()
        
        self.get_logger().info('Simulated Image Publisher started')
        
    def create_simulated_scene(self):
        # 创建一个基本背景
        self.background = np.ones((480, 640, 3), dtype=np.uint8) * 200  # 浅灰色背景
        
        # 添加一些简单的物体
        # 红色方块 (苹果模拟)
        cv2.rectangle(self.background, (100, 100), (200, 200), (0, 0, 255), -1)
        cv2.putText(self.background, "Apple", (110, 150), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # 棕色圆形 (杯子模拟)
        cv2.circle(self.background, (350, 150), 50, (42, 42, 165), -1)
        cv2.putText(self.background, "Cup", (330, 150), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # 蓝色矩形 (笔记本电脑模拟)
        cv2.rectangle(self.background, (450, 300), (600, 350), (255, 0, 0), -1)
        cv2.putText(self.background, "Laptop", (480, 330), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # 黄色椭圆 (玩具熊模拟)
        cv2.ellipse(self.background, (200, 350), (70, 90), 0, 0, 360, (0, 255, 255), -1)
        cv2.putText(self.background, "Teddy Bear", (160, 350), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2)
        
    def timer_callback(self):
        # 创建每帧的副本，稍后可能添加移动效果
        frame = self.background.copy()
        
        # 将OpenCV图像转换为ROS图像消息
        image_message = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")
        
        # 设置帧ID和时间戳
        image_message.header.frame_id = "camera_link"
        image_message.header.stamp = self.get_clock().now().to_msg()
        
        # 发布图像
        self.publisher_.publish(image_message)

def main(args=None):
    rclpy.init(args=args)
    
    simulated_image_publisher = SimulatedImagePublisher()
    
    try:
        rclpy.spin(simulated_image_publisher)
    except KeyboardInterrupt:
        pass
    finally:
        simulated_image_publisher.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
