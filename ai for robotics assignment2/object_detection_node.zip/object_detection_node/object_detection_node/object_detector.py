#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from vision_msgs.msg import Detection2D, Detection2DArray, ObjectHypothesisWithPose
from cv_bridge import CvBridge
from std_msgs.msg import String
import cv2
import numpy as np

class SimpleObjectDetector(Node):
    def __init__(self):
        super().__init__('simple_object_detector')
        
        # 初始化CV Bridge
        self.bridge = CvBridge()
        
        # 初始化HOG行人检测器（用于检测人）
        self.hog = cv2.HOGDescriptor()
        self.hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
        
        # 订阅摄像头话题
        self.camera_subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10
        )
        
        # 发布检测结果
        self.detection_publisher = self.create_publisher(
            Detection2DArray,
            'object_detections',
            10
        )
        
        # 发布可视化的图像
        self.image_publisher = self.create_publisher(
            Image,
            '/object_detection/image',
            10
        )
        
        # 发布检测摘要
        self.detection_summary_publisher = self.create_publisher(
            String,
            'detection_summary',
            10
        )
        
        self.get_logger().info('Simple Object Detector Node initialized')
    
    def detect_objects_by_color(self, image):
        """使用颜色阈值检测常见物体"""
        # 转换到HSV颜色空间，更容易进行颜色分割
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        height, width = image.shape[:2]
        
        detections = []
        
        # 检测红色物体（可能是苹果、红色杯子等）
        lower_red1 = np.array([0, 100, 100])
        upper_red1 = np.array([10, 255, 255])
        lower_red2 = np.array([160, 100, 100])
        upper_red2 = np.array([180, 255, 255])
        
        red_mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
        red_mask2 = cv2.inRange(hsv, lower_red2, upper_red2)
        red_mask = red_mask1 + red_mask2
        
        # 检测绿色物体（可能是植物、蔬菜等）
        lower_green = np.array([35, 50, 50])
        upper_green = np.array([85, 255, 255])
        green_mask = cv2.inRange(hsv, lower_green, upper_green)
        
        # 检测蓝色物体
        lower_blue = np.array([90, 50, 50])
        upper_blue = np.array([130, 255, 255])
        blue_mask = cv2.inRange(hsv, lower_blue, upper_blue)
        
        # 形态学操作，去除噪点
        kernel = np.ones((5, 5), np.uint8)
        red_mask = cv2.morphologyEx(red_mask, cv2.MORPH_OPEN, kernel)
        green_mask = cv2.morphologyEx(green_mask, cv2.MORPH_OPEN, kernel)
        blue_mask = cv2.morphologyEx(blue_mask, cv2.MORPH_OPEN, kernel)
        
        # 找到轮廓并识别对象
        for mask, color_name in [(red_mask, "red_object"), (green_mask, "green_object"), (blue_mask, "blue_object")]:
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            for contour in contours:
                area = cv2.contourArea(contour)
                
                # 过滤掉太小的区域
                if area > 500:  # 可以调整这个阈值
                    x, y, w, h = cv2.boundingRect(contour)
                    
                    # 仅保留合理比例的框
                    if 0.5 < w/h < 2.0:
                        detections.append((x, y, w, h, color_name))
        
        return detections
    
    def image_callback(self, msg):
        """处理输入的摄像头图像并执行物体检测"""
        try:
            # 转换ROS图像消息为OpenCV图像
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            
            # 创建一个副本用于绘制检测结果
            result_image = cv_image.copy()
            
            # 创建ROS检测消息
            detection_array_msg = Detection2DArray()
            detection_array_msg.header = msg.header
            
            # 跟踪检测到的物体
            detected_objects = {}
            
            # 使用HOG检测人
            people, _ = self.hog.detectMultiScale(
                cv_image, 
                winStride=(8, 8),
                padding=(4, 4),
                scale=1.05
            )
            
            # 处理人的检测结果
            for (x, y, w, h) in people:
                self.add_detection(x, y, w, h, "person", msg.header, result_image, 
                                  detection_array_msg, detected_objects)
            
            # 使用颜色检测其他物体
            color_detections = self.detect_objects_by_color(cv_image)
            
            # 处理颜色检测结果
            for (x, y, w, h, obj_type) in color_detections:
                self.add_detection(x, y, w, h, obj_type, msg.header, result_image, 
                                  detection_array_msg, detected_objects)
            
            # 发布检测数组
            self.detection_publisher.publish(detection_array_msg)
            
            # 发布可视化图像
            image_msg = self.bridge.cv2_to_imgmsg(result_image, encoding='bgr8')
            image_msg.header = msg.header
            self.image_publisher.publish(image_msg)
            
            # 发布检测摘要
            if detected_objects:
                summary_text = "Detected objects: " + ", ".join([f"{count} {obj}" for obj, count in detected_objects.items()])
                summary_msg = String()
                summary_msg.data = summary_text
                self.detection_summary_publisher.publish(summary_msg)
                self.get_logger().info(summary_text)
            
        except Exception as e:
            self.get_logger().error(f'Error processing image: {str(e)}')
    
    def add_detection(self, x, y, w, h, obj_type, header, image, detection_array_msg, detected_objects):
        """添加检测结果到消息和图像中"""
        # 创建Detection2D消息
        detection_msg = Detection2D()
        detection_msg.header = header
        
        # 设置边界框
        detection_msg.bbox.center.x = float(x + w / 2)
        detection_msg.bbox.center.y = float(y + h / 2)
        detection_msg.bbox.size_x = float(w)
        detection_msg.bbox.size_y = float(h)
        
        # 设置假设
        hypothesis = ObjectHypothesisWithPose()
        hypothesis.id = obj_type
        hypothesis.score = 1.0
        detection_msg.results.append(hypothesis)
        
        # 添加到检测数组
        detection_array_msg.detections.append(detection_msg)
        
        # 更新检测到的物体计数
        if obj_type in detected_objects:
            detected_objects[obj_type] += 1
        else:
            detected_objects[obj_type] = 1
        
        # 在图像上绘制检测结果
        cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(image, obj_type, (x, y - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

def main(args=None):
    rclpy.init(args=args)
    node = SimpleObjectDetector()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()